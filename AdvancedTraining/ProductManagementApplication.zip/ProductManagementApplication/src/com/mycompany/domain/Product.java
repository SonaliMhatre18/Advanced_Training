package com.mycompany.domain;

public class Product {
	String ProductID;
	String ProductName;
	float ProductPrice;

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(String productID, String productName, float productPrice) {
		super();
		ProductID = productID;
		ProductName = productName;
		ProductPrice = productPrice;
	}

	public String getProductID() {
		return ProductID;
	}

	public void setProductID(String productID) {
		ProductID = productID;
	}

	public String getProductName() {
		return ProductName;
	}

	public void setProductName(String productName) {
		ProductName = productName;
	}

	public float getProductPrice() {
		return ProductPrice;
	}

	public void setProductPrice(float productPrice) {
		ProductPrice = productPrice;
	}


}
