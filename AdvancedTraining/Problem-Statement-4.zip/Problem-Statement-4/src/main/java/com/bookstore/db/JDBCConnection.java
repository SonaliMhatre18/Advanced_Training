package com.bookstore.db;

import java.sql.DriverManager;

import com.mysql.jdbc.Connection;

public class JDBCConnection {
	private static Connection conn;

	public static Connection getConnection() {
		try {
			if (conn == null) {
				Class.forName("com.mysql.cj.jdbc.Driver");
				conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/productdb", "root",
						"Mansi@1208");
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return conn;
	}

}
