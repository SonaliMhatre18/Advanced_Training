package com.bookstore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bookstore.entity.User;

public class UserDao {
	private Connection conn;

	public UserDao(Connection conn) {
		super();
		this.conn = conn;
	}

	// Method to insert in database
	public boolean saveUser(User user) {
		boolean flag = false;
		try {
			String query = "insert into Users(firstName, address, email, userName, password) values (?,?,?,?,?)";
			PreparedStatement ps = this.conn.prepareStatement(query);
			ps.setString(1, user.getFirstName());
			ps.setString(2, user.getAddress());
			ps.setString(3, user.getEmail());
			ps.setString(4, user.getUserName());
			ps.setString(5, user.getPassword());

			ps.executeUpdate();
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public User getUserByNameAndPassword(String userName, String password) {
		User user = null;

		try {
			String query = "select * from Users where userName = ? and password = ?";
			PreparedStatement ps = this.conn.prepareStatement(query);
			ps.setString(1, userName);
			ps.setString(2, password);

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				user = new User();
				// data from database
				user.setFirstName(rs.getString("firstName"));
				// set to user object
				user.setEmail(rs.getString("email"));
				user.setAddress(rs.getString("address"));
				user.setUserName(userName);
				user.setPassword(password);
				user.setRegistrationDate(rs.getTimestamp("registrationDate"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return user;
	}

}
