package com.example.shoppingcartapplication.Dao;

import java.util.List;

import com.example.shoppingcartapplication.entity.Product;

public interface ProductDao {
	public void addProduct(Product product);

	public void findByProductId(int id);

	public void deleteByProductId(int id);

	public void updateByProductId(int id);

	public List<Product> allProduct();

	public void findByCategory(String name);

	public void brandAndModel(String brandAndModel);

	public void brandOrModel(String brandOrModel);

	public void brandOrModelOrCategory(String brandOrModelOrCategory);

}
