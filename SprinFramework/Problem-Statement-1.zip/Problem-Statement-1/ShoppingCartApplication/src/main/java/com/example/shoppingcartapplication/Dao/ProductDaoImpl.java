package com.example.shoppingcartapplication.Dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.shoppingcartapplication.entity.Product;

public class ProductDaoImpl implements ProductDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		Session currentSession = sessionFactory.getCurrentSession();
		currentSession.saveOrUpdate(product);

	}

	@Override
	public void findByProductId(int id) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteByProductId(int id) {
		// TODO Auto-generated method stub
		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		// delete object with primary key
		Query theQuery = currentSession.createQuery("delete from Product where id=:productId");
		theQuery.setParameter("productId", id);

		theQuery.executeUpdate();

	}

	@Override
	public void updateByProductId(int id) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Product> allProduct() {
		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		// create a query
		Query<Product> theQuery = currentSession.createQuery("from Product", Product.class);

		// execute query and get result list
		List<Product> products = theQuery.getResultList();

		// return the results
		return products;
	}

	@Override
	public void findByCategory(String name) {
		// TODO Auto-generated method stub

	}

	@Override
	public void brandAndModel(String brandAndModel) {
		// TODO Auto-generated method stub

	}

	@Override
	public void brandOrModel(String brandOrModel) {
		// TODO Auto-generated method stub

	}

	@Override
	public void brandOrModelOrCategory(String brandOrModelOrCategory) {
		// TODO Auto-generated method stub

	}

}
