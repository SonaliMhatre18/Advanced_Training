package com.problem.statement;

public class MedicineInfo {
	private String companyName;
	private String address;
	
	MedicineInfo(String x, String y) {
		companyName = x;
		address = y;
	}
	
	public void displayLable1() {
		System.out.println("Company Name: " + companyName);
		System.out.println("Address: " + address);
	}

}
