package com.problem.statement3;


public abstract class Instrument {
	public abstract void play();

}
