package com.simplilearn.storage;

import java.util.ArrayList;
import java.util.List;

public class Storage {
	
	public static boolean flag = false;
	
	private List<Integer> listOfNumbers = new ArrayList<>();
	
	public  void storeValues(Integer num) {
		
		listOfNumbers.add(num);
	}
	
	public  void readValues() {
		
		for(Integer val:listOfNumbers) {
			System.out.println("Printer : "+val+" ");

		}
	}

}
