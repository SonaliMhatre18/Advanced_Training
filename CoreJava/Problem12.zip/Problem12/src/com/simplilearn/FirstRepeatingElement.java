package com.simplilearn;


import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class FirstRepeatingElement {

	public static int findFirstRepeatingElement(int[] arr) {
		 
		Set<Integer> set = new HashSet<Integer>();
		
		int element = 0;
		
		for(int num:arr) {
			
			if(! set.add(num)) {
				
				element = num;
				break;
			}
			
			set.add(num);
		}
		
		return element;
		
	}
	public static void main(String[] args) {
		
		int[] arr1 = { 1, 2, 3, 10, 2, 4, 5, 7, 8 };
		int[] arr2 = { 1, 2, 3, 10, 6, 4, 3, 7, 10};
		
		System.out.println("First Repeating of the 1st array is -> "+findFirstRepeatingElement(arr1));
				
		System.out.println("First Repeating of the 2nd array  is -> "+findFirstRepeatingElement(arr2));
		
		

	}

}
